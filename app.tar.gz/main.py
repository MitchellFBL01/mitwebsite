import flet as ft


def main(page: ft.Page):
    page.title = "Calc App"
    result = ft.Text(value="")
    page.window_height = 450
    page.window_width = 400
    page.window_resizable = False
    page.padding = 0

    def buttonenPantalla(e):
        data = str(e.control.data)
        if data in ("menor"):
            if float(result.value) > 0:
                result.value = "-" + str(result.value)
            elif float(result.value) < 0:
                    result.value = str(
                        abs(float(result.value))
                    )
        elif data in ("%"):
            result.value = str(float(result.value) / 100)
        
        elif data in ("AC"):
            result.value = ""
        
        elif data in ("-", "*", "+", "/"):
            if result.value[-1] == "-":
                resultado = result.value.replace("-", data)
                result.value = resultado
                
                print(result.value)
                print(data)
                print(resultado)
                
            elif result.value[-1] == "+":
                resultado = result.value.replace("+", data)
                result.value = resultado

            elif result.value[-1] == "*":
                resultado = result.value.replace("*", data)
                result.value = resultado

            elif result.value[-1] == "/":
                resultado = result.value.replace("/", data)
                result.value = resultado

            else:
                result.value += data

        else:
            result.value += data
            print(result.value[-1])

        page.update()
    
    def calculate(e):
        try:
            resultado = str(format(eval(result.value),".2f"))
        except:
            resultado = "ERROR"
        
        result.value = resultado
        resultado = 0
        page.update()
        
    itensPantalla = [
        result
    ]

    itensControles = [
        ft.Row(controls=[
                ft.ElevatedButton(text="AC ",on_click=buttonenPantalla, data="AC"),
                ft.ElevatedButton(text="+/-", on_click=buttonenPantalla, data="menor"),
                ft.ElevatedButton(text=" % ", on_click=buttonenPantalla, data="%"),
                ft.ElevatedButton(text=" / ", on_click=buttonenPantalla, data="/"),
            ])
    ]

    itensPrimera = [
        ft.Row(
            controls=[
                ft.ElevatedButton(text=" 7 ", on_click=buttonenPantalla, data="7"),
                ft.ElevatedButton(text=" 8 ", on_click=buttonenPantalla, data="8"),
                ft.ElevatedButton(text=" 9 ", on_click=buttonenPantalla, data="9"),
                ft.ElevatedButton(text=" * ", on_click=buttonenPantalla, data="*"),
            ]
        )
    ]

    itensSegunda = [
        ft.Row(
            controls=[
                ft.ElevatedButton(text=" 4 ", on_click=buttonenPantalla, data="4"),
                ft.ElevatedButton(text=" 5 ", on_click=buttonenPantalla, data="5"),
                ft.ElevatedButton(text=" 6 ", on_click=buttonenPantalla, data="6"),
                ft.ElevatedButton(text=" - ", on_click=buttonenPantalla, data="-"),
            ]
        )
    ]

    itensTercera = [
        ft.Row(
            controls=[
                ft.ElevatedButton(text=" 1 ", on_click=buttonenPantalla, data="1"),
                ft.ElevatedButton(text=" 2 ", on_click=buttonenPantalla, data="2"),
                ft.ElevatedButton(text=" 3 ", on_click=buttonenPantalla, data="3"),
                ft.ElevatedButton(text=" + ", on_click=buttonenPantalla, data="+"),
            ]
        )
    ]

    itensceroIgual = [
        ft.Row(
            controls=[
                ft.ElevatedButton(text="               0               ",
                style=ft.ButtonStyle(padding=10, shape=ft.RoundedRectangleBorder(radius=10)), on_click=buttonenPantalla, data="0"),
                ft.ElevatedButton(text=" . ", on_click=buttonenPantalla, data="."),
                ft.ElevatedButton(text=" = ", on_click=calculate, data="=")
            ]
        )
    ]


    pantalla  = ft.Container(content=ft.Row(itensPantalla,  alignment= ft.MainAxisAlignment.END), padding=20,         width=350, height=80, bgcolor=ft.colors.BLUE_500)
    controles = ft.Container(content=ft.Row(itensControles, alignment= ft.MainAxisAlignment.SPACE_AROUND), width=350, height=50)
    primera   = ft.Container(content=ft.Row(itensPrimera,   alignment= ft.MainAxisAlignment.SPACE_AROUND), width=350, height=50)
    segunda   = ft.Container(content=ft.Row(itensSegunda,   alignment= ft.MainAxisAlignment.SPACE_AROUND), width=350, height=50)
    tercera   = ft.Container(content=ft.Row(itensTercera,   alignment= ft.MainAxisAlignment.SPACE_AROUND), width=350, height=50)
    ceroIgual = ft.Container(content=ft.Row(itensceroIgual, alignment= ft.MainAxisAlignment.SPACE_EVENLY), width=350, height=50)

    columnas = ft.Column(spacing= 5, controls=[
        pantalla,
        controles,
        primera,
        segunda,
        tercera,
        ceroIgual,
    ])



    guijarro = ft.Container(columnas, width=400, height=450, bgcolor=ft.colors.BLACK ,alignment=ft.alignment.top_center, padding=20)

    page.add(guijarro)

ft.app(target=main)